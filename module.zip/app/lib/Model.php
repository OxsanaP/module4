<?php
namespace app\lib;

class Model
{
    public function getData()
    {
    }
}