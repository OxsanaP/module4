<div class="row ads-row">
    <div class="col-md-12">
        <p>Продам Рога</p>
        <p class="price"><span class="price-value">1000</span> гр</p>
        <p class="cupon">Купон на скидку  - <?php echo uniqid() ?> – примените и получите скидку 10%. </p>
        <p>Рога и Копыта - www.roga.com</p>
    </div>
</div>
<div class="row ads-row">
    <div class="col-md-12">
        <p>Продам Копыта</p>
        <p class="price"><span class="price-value">2000</span> гр</p>
        <p class="cupon">Купон на скидку  - <?php echo uniqid() ?> – примените и получите скидку 10%. </p>
        <p>Рога и Копыта - www.roga.com</p>
    </div>
</div>
<div class="row ads-row">
    <div class="col-md-12">
        <p>Продам Шерсть</p>
        <p class="price"><span class="price-value">3000</span> гр</p>
        <p class="cupon">Купон на скидку  - <?php echo uniqid() ?> – примените и получите скидку 10%. </p>
        <p>Рога и Копыта - www.roga.com</p>
    </div>
</div>
<div class="row ads-row">
    <div class="col-md-12">
        <p>Продам Хвост</p>
        <p class="price"><span class="price-value">8000</span> гр</p>
        <p class="cupon">Купон на скидку  - <?php echo uniqid() ?> – примените и получите скидку 10%. </p>
        <p>Рога и Копыта - www.roga.com</p>
    </div>
</div>