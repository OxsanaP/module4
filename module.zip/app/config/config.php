<?php
define('BP', dirname(dirname(__FILE__)));
define('DS', "/");

// Db
define('DB_USER', 'root');
define('DB_PASS', 'fender');
define('DB_HOST', 'localhost');
define('DB_NAME', 'mvc');

//$dbObject = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME, DB_USER, DB_PASS);
